<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $pose_id = $_GET['id'];

    // 1. Select the specified pose from 'pose' table
    $sql_select = "SELECT * FROM pose WHERE id = ?";
    $stmt_select = $conn->prepare($sql_select);
    $stmt_select->bind_param("i", $pose_id);
    $stmt_select->execute();
    $result = $stmt_select->get_result();
    
    if ($result->num_rows > 0) {
        $pose = $result->fetch_assoc();

        // 2. Clear any old data from 'run' table (optional, ensures only one row)
        $conn->query("TRUNCATE TABLE run");

        // 3. Insert the new pose into 'run' table with status = 1
        $sql_insert = "INSERT INTO run (servo1, servo2, servo3, servo4, servo5, servo6, status) VALUES (?, ?, ?, ?, ?, ?, 1)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("iiiiii", $pose['servo1'], $pose['servo2'], $pose['servo3'], $pose['servo4'], $pose['servo5'], $pose['servo6']);
        
        if ($stmt_insert->execute()) {
            echo "Pose loaded to run table successfully!";
        } else {
            echo "Error loading pose: " . $conn->error;
        }
        $stmt_insert->close();
    } else {
        echo "Pose not found.";
    }
    $stmt_select->close();
} else {
    echo "No pose ID provided.";
}

$conn->close();
?>
