<?php
include 'db_connection.php';

// Get the row where status is 1 (only one row expected)
$sql = "SELECT servo1, servo2, servo3, servo4, servo5, servo6 FROM run WHERE status = 1 LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Print the values separated by commas
    echo implode(",", [
        $row['servo1'],
        $row['servo2'],
        $row['servo3'],
        $row['servo4'],
        $row['servo5'],
        $row['servo6']
    ]);
} else {
    // Return error message if no data found
    echo "No data to run";
}

$conn->close();
?>
