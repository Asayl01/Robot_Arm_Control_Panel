<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $pose_id = $_GET['id'];

    // Prepare and execute delete query
    $sql = "DELETE FROM pose WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $pose_id);

    if ($stmt->execute()) {
        echo "Pose removed successfully!";
    } else {
        echo "Error removing pose: " . $conn->error;
    }

    $stmt->close();
} else {
    // ID not provided
    echo "No pose ID provided.";
}

$conn->close();
?>
