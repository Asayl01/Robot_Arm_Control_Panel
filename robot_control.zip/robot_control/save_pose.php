<?php
include 'db_connection.php';

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Receive motor values from the form
    $motor1 = $_POST['motor1'];
    $motor2 = $_POST['motor2'];
    $motor3 = $_POST['motor3'];
    $motor4 = $_POST['motor4'];
    $motor5 = $_POST['motor5'];
    $motor6 = $_POST['motor6'];

    // Prepare SQL query to insert the data
    $sql = "INSERT INTO pose (servo1, servo2, servo3, servo4, servo5, servo6) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Bind variables to the statement
    $stmt->bind_param("iiiiii", $motor1, $motor2, $motor3, $motor4, $motor5, $motor6);

    // Execute the query
    if ($stmt->execute()) {
        echo "Pose saved successfully!";
    } else {
        echo "Error: " . $sql . "  
" . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
