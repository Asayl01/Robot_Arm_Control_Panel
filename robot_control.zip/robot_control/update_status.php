<?php
include 'db_connection.php';

// Update status field to 0
$sql = "UPDATE run SET status = 0 WHERE status = 1";

if ($conn->query($sql) === TRUE) {
    // Check if any row was updated
    if ($conn->affected_rows > 0) {
        echo "Status updated to 0 successfully.";
    } else {
        echo "No active run found to update.";
    }
} else {
    echo "Error updating status: " . $conn->error;
}

$conn->close();
?>
