<?php
header('Content-Type: application/json');
include 'db_connection.php';

$sql = "SELECT id, servo1, servo2, servo3, servo4, servo5, servo6 FROM pose";
$result = $conn->query($sql);

$poses = array();

if ($result->num_rows > 0) {
    // Fetch data row by row
    while($row = $result->fetch_assoc()) {
        $poses[] = $row;
    }
}

echo json_encode($poses);

$conn->close();
?>
