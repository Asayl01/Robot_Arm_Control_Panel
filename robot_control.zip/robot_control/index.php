<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robot Arm Control Panel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <h1>Robot Arm Control Panel</h1>

        <div class="control-panel">
            <form id="poseForm">
                <?php for ($i = 1; $i <= 6; $i++): ?>
                <div class="motor-control">
                    <label for="motor<?php echo $i; ?>">Motor <?php echo $i; ?>:</label>
                    <input type="range" id="motor<?php echo $i; ?>" name="motor<?php echo $i; ?>" min="0" max="180" value="90" oninput="updateSliderValue(this.id)">
                    <span id="motor<?php echo $i; ?>_val">90</span>
                </div>
                <?php endfor; ?>

                <div class="buttons">
                    <button type="button" onclick="savePose()">Save Pose</button>
                    <button type="button" class="run-btn" onclick="runPose()">Run</button>
                    <button type="reset" onclick="resetSliders()">Reset</button>
                </div>
            </form>
        </div>

        <div class="poses-table">
            <h2>Saved Poses</h2>
            <table id="posesTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Motor 1</th>
                        <th>Motor 2</th>
                        <th>Motor 3</th>
                        <th>Motor 4</th>
                        <th>Motor 5</th>
                        <th>Motor 6</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data will be loaded here using JavaScript -->
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Update the value shown next to the slider
        function updateSliderValue(sliderId) {
            var slider = document.getElementById(sliderId);
            var output = document.getElementById(sliderId + '_val');
            output.innerHTML = slider.value;
        }

        // Reset sliders to value 90
        function resetSliders() {
            for (let i = 1; i <= 6; i++) {
                document.getElementById('motor' + i).value = 90;
                document.getElementById('motor' + i + '_val').innerText = 90;
            }
        }

        // On page load, get poses and reset sliders
        window.onload = function() {
            getPoses();
            resetSliders();
        };

        // Fetch saved poses from database
        function getPoses() {
            fetch('get_poses.php')
                .then(response => response.json())
                .then(data => {
                    const tableBody = document.querySelector("#posesTable tbody");
                    tableBody.innerHTML = "";
                    data.forEach(pose => {
                        const row = `<tr>
                            <td>${pose.id}</td>
                            <td>${pose.servo1}</td>
                            <td>${pose.servo2}</td>
                            <td>${pose.servo3}</td>
                            <td>${pose.servo4}</td>
                            <td>${pose.servo5}</td>
                            <td>${pose.servo6}</td>
                            <td class="action-buttons">
                                <button onclick="loadPose(${pose.id})">Load</button>
                                <button onclick="removePose(${pose.id})">Remove</button>
                            </td>
                        </tr>`;
                        tableBody.innerHTML += row;
                    });
                });
        }

        // Save the current pose to the database
        function savePose() {
            const formData = new FormData(document.getElementById('poseForm'));
            fetch('save_pose.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                alert(result);
                getPoses();
            });
        }

        // Send current pose to the 'run' table
        function runPose() {
            const formData = new FormData(document.getElementById('poseForm'));
            fetch('run_now.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                alert(result);
            });
        }

        // Load a saved pose
        function loadPose(poseId) {
             fetch(`load_pose.php?id=${poseId}`)
            .then(response => response.text())
            .then(result => {
                alert(result);
            });
        }

        // Delete a saved pose
        function removePose(poseId) {
            if (confirm('Are you sure you want to remove this pose?')) {
                fetch(`remove_pose.php?id=${poseId}`)
                .then(response => response.text())
                .then(result => {
                    alert(result);
                    getPoses();
                });
            }
        }
    </script>
</body>
</html>
